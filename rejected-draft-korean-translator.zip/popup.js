const STORAGE_KEY = "rejectedDraftKoEnabled";

const enabledInput = document.querySelector("#enabled");
const statusEl = document.querySelector("#status");

function setStatus(text) {
  statusEl.textContent = text;
}

chrome.storage.local.get({ [STORAGE_KEY]: true }, (result) => {
  enabledInput.checked = Boolean(result[STORAGE_KEY]);
});

enabledInput.addEventListener("change", () => {
  chrome.storage.local.set({ [STORAGE_KEY]: enabledInput.checked }, () => {
    setStatus("설정을 저장했습니다. 게임 탭을 새로고침하세요.");
  });
});
